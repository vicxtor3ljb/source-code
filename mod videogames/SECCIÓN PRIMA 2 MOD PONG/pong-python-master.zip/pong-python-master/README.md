# pong-python
Single player pong game in python using pygame library.

Use left and right arrow keys to move the paddle. 
Be gentle! 
Dont press both keys simultaneously or the paddle gets stuck for a second.
