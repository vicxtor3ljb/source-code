from .config import main
main()
