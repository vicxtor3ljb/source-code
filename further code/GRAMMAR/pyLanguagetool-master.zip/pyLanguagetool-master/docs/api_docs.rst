API Reference
=============

HTTP API
--------

.. automodule:: pylanguagetool.api
   :members:

CLI
---


.. automodule:: pylanguagetool
   :members:

Converters
----------

.. automodule:: pylanguagetool.converters
   :members:
